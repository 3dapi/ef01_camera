// Implementation of the CMcBillboard class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


INT	 McUtil_TextureLoad(LPDIRECT3DDEVICE9	pDev
						, TCHAR * sFile
						, LPDIRECT3DTEXTURE9& pTx
						, DWORD color=0xFF000000
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter   = (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN)
{
	if ( FAILED(D3DXCreateTextureFromFileEx(
		pDev
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, color
		, pSrcInfo
		, NULL
		, &pTx
		)) )
	{
		pTx = NULL;
		return -1;
	}
	
	return 0;
}


CMcBillboard::CMcBillboard()
{
	m_pDev	= NULL;
}

CMcBillboard::~CMcBillboard()
{
	Destroy();
}


INT CMcBillboard::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	INT i=0;

	McUtil_TextureLoad(m_pDev, "Texture/tree01S.dds", m_pTex, 0x00FFFFFF, &m_pImg);

	m_vcPos	= D3DXVECTOR3(100, 10, 30);

	m_pVtx[0] = VtxUV1(0, 0, 0,   0, 1);
	m_pVtx[1] = VtxUV1(0, 0, 0,   0, 0);
	m_pVtx[2] = VtxUV1(0, 0, 0,   1, 0);
	m_pVtx[3] = VtxUV1(0, 0, 0,   1, 1);

	return 0;
}


void CMcBillboard::Destroy()
{
	SAFE_RELEASE(	m_pTex	);
}


INT CMcBillboard::FrameMove()
{
	D3DXMATRIX mtBill;

	m_pDev->GetTransform(D3DTS_VIEW, &mtBill);
	D3DXMatrixInverse(&mtBill, 0, &mtBill);

	mtBill._41 = 0;
	mtBill._42 = 0;
	mtBill._43 = 0;

	FLOAT		fX;
	FLOAT		fY;
	D3DXVECTOR3	Vtx[4];
	D3DXVECTOR3	vcTmp;

	fX = m_pImg.Width* 2.f;
	fY = m_pImg.Height* 2.f;

	Vtx[0] = D3DXVECTOR3(-fX,-fY, 0);
	Vtx[1] = D3DXVECTOR3(-fX, fY, 0);
	Vtx[2] = D3DXVECTOR3( fX, fY, 0);
	Vtx[3] = D3DXVECTOR3( fX,-fY, 0);

	D3DXVec3TransformCoord(&m_pVtx[0].p, &Vtx[0], &mtBill);
	D3DXVec3TransformCoord(&m_pVtx[1].p, &Vtx[1], &mtBill);
	D3DXVec3TransformCoord(&m_pVtx[2].p, &Vtx[2], &mtBill);
	D3DXVec3TransformCoord(&m_pVtx[3].p, &Vtx[3], &mtBill);

	m_pVtx[0].p += m_vcPos;
	m_pVtx[1].p += m_vcPos;
	m_pVtx[2].p += m_vcPos;
	m_pVtx[3].p += m_vcPos;

	m_pVtx[0].p.y += fY * 1.f;
	m_pVtx[1].p.y += fY * 1.f;
	m_pVtx[2].p.y += fY * 1.f;
	m_pVtx[3].p.y += fY * 1.f;

	return 0;
}


void CMcBillboard::Render()
{
	INT	i=0;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);



	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	m_pDev->SetFVF(VtxUV1::FVF);
	m_pDev->SetTexture(0, m_pTex);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, &m_pVtx, sizeof(VtxUV1));


	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

}

