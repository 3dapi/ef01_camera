// Implementation of the CMcCamera class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCamera::CMcCamera()
{
	m_pDev	= NULL;
}

CMcCamera::~CMcCamera()
{

}


INT CMcCamera::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev		= pDev;

	m_vcEye		= D3DXVECTOR3(0,50,-100);
	m_vcLook	= D3DXVECTOR3(0,0,0);
	m_vcUp		= D3DXVECTOR3(0,1,0);

	m_fNear		= 1.f;
	m_fFar		= 5000.f;
	m_fAspc		= 800.f/600.f;
	m_fFOV		= D3DX_PI/4.f;

	D3DXMatrixPerspectiveFovLH(&m_mtPrj, m_fFOV, m_fAspc, m_fNear, m_fFar);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	return 0;
}


INT CMcCamera::FrameMove()
{
	D3DXVECTOR3 vcDelta = g_pApp->m_pInput->GetMouseEps();

	if(vcDelta.z !=0.f)
		MoveForward(-vcDelta.z* .1f, 1.f);

	if(g_pApp->m_pInput->KeyState('W'))
		MoveForward( 4.f, 1.f);

	if(g_pApp->m_pInput->KeyState('S'))
		MoveForward(-4.f, 1.f);

	if(g_pApp->m_pInput->KeyState('A'))
		MoveSideward(-4.f);

	if(g_pApp->m_pInput->KeyState('D'))
		MoveSideward(4.f);

	if(g_pApp->m_pInput->BtnState(1))
		Rotate(&vcDelta, .2f);

	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);

	UpdateMatrix();

	return 0;
}


void CMcCamera::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamera::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	D3DXVECTOR3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}

void CMcCamera::Rotate(const D3DXVECTOR3* vcDelta, float fSpeed)
{
	D3DXVECTOR3 vcEps = *vcDelta;

	FLOAT	fYaw	;
	FLOAT	fPitch	;

	D3DXVECTOR3 vcZ;
	D3DXVECTOR3 vcY;
	D3DXVECTOR3 vcX;

	D3DXMATRIX rtY;
	D3DXMATRIX rtX;

	// ���� ��ǥ y �࿡ ���� ȸ��
	fYaw	= D3DXToRadian(vcEps.x * fSpeed);
	D3DXMatrixRotationY(&rtY, fYaw);

	vcZ = m_vcLook-m_vcEye;
	vcY = D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);

	D3DXVec3TransformCoord(&vcZ, &vcZ, &rtY);
	D3DXVec3TransformCoord(&vcY, &vcY, &rtY);

	m_vcLook= vcZ + m_vcEye;
	m_vcUp	= vcY;
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);


	// ī�޶��� x �࿡ ���� ȸ��
	fPitch	= D3DXToRadian(vcEps.y * fSpeed);
	vcX	= D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
	vcY = D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);
	vcZ = m_vcLook-m_vcEye;

	D3DXMatrixRotationAxis(&rtX, &vcX, fPitch);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rtX);
	D3DXVec3TransformCoord(&vcY, &vcY, &rtX);

	m_vcLook= vcZ + m_vcEye;
	m_vcUp	= vcY;
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}



void CMcCamera::UpdateMatrix()
{
	D3DXMATRIX		mtVP;		// View * Projection
	D3DXMATRIX		mtVPInv;	// View * Projection Inverse Matrix

	mtVP = m_mtViw * m_mtPrj;
	D3DXMatrixInverse(&mtVPInv, NULL, &mtVP);

	D3DXVECTOR3		vcZ  = D3DXVECTOR3(m_mtViw._13, m_mtViw._23, m_mtViw._33);
	FLOAT			Near = m_fNear;
	FLOAT			Far  = m_fFar;
	D3DXVECTOR3		vcEye= m_vcEye;

	// 1. Near Plane
	D3DXVECTOR3		vcNear;
	FLOAT			Dnear;

	vcNear = -vcZ;
	Dnear  = -D3DXVec3Dot(&vcNear, &vcEye) + Near;
	m_Frst[0] = D3DXPLANE(vcNear.x, vcNear.y, vcNear.z, Dnear);


	// 2. Far Plane
	D3DXVECTOR3		vcFar;
	FLOAT			Dfar;

	vcFar = vcZ;
	Dfar  = -D3DXVec3Dot(&vcFar, &vcEye) - Far;
	m_Frst[1] = D3DXPLANE(vcFar.x, vcFar.y, vcFar.z, Dfar);


	// 3. Left, Right, Up, Down ���
	D3DXVECTOR3		vcPyr[4];			// �Ƕ�� ������ 4��
	vcPyr[0] = D3DXVECTOR3(-1.f, -1.f, 0.f);
	vcPyr[1] = D3DXVECTOR3(-1.f,  1.f, 0.f);
	vcPyr[2] = D3DXVECTOR3( 1.f,  1.f, 0.f);
	vcPyr[3] = D3DXVECTOR3( 1.f, -1.f, 0.f);


	// Un Projection, Un View
	for(int i = 0; i < 4; ++i)
		D3DXVec3TransformCoord( &vcPyr[i], &vcPyr[i], &mtVPInv);

	// 3. ����� ������ǥ�� Frustum ����� �����. ���ʹ� �ȿ��� ������ ������ ����.
	D3DXPlaneFromPoints(&m_Frst[2], vcPyr+0, vcPyr+1, &vcEye);			// (left)
	D3DXPlaneFromPoints(&m_Frst[3], vcPyr+2, vcPyr+3, &vcEye);			// (right)
	D3DXPlaneFromPoints(&m_Frst[4], vcPyr+1, vcPyr+2, &vcEye);			// (up)
	D3DXPlaneFromPoints(&m_Frst[5], vcPyr+3, vcPyr+0, &vcEye);			// (down)


//
//	D3DXPLANE	plL(0, 0, 0, 0);	// Left
//	D3DXPLANE	plR(0, 0, 0, 0);	// Right
//	D3DXPLANE	plU(0, 0, 0, 0);	// Up
//	D3DXPLANE	plD(0, 0, 0, 0);	// Down
//	D3DXPLANE	plN(0, 0, 0, 0);	// Near
//	D3DXPLANE	plF(0, 0, 0, 0);	// Far
//
//	plL.a = -(mtVP._14 + mtVP._11);
//	plL.b = -(mtVP._24 + mtVP._21);
//	plL.c = -(mtVP._34 + mtVP._31);
//	plL.d = -(mtVP._44 + mtVP._41);
//	D3DXPlaneNormalize(&plL, &plL);
//
//	plR.a = -(mtVP._14 - mtVP._11);
//	plR.b = -(mtVP._24 - mtVP._21);
//	plR.c = -(mtVP._34 - mtVP._31);
//	plR.d = -(mtVP._44 - mtVP._41);
//	D3DXPlaneNormalize(&plR, &plR);
//
//	plU.a = -(mtVP._14 - mtVP._12);
//	plU.b = -(mtVP._24 - mtVP._22);
//	plU.c = -(mtVP._34 - mtVP._32);
//	plU.d = -(mtVP._44 - mtVP._42);
//	D3DXPlaneNormalize(&plU, &plU);
//
//	plD.a = -(mtVP._14 + mtVP._12);
//	plD.b = -(mtVP._24 + mtVP._22);
//	plD.c = -(mtVP._34 + mtVP._32);
//	plD.d = -(mtVP._44 + mtVP._42);
//	D3DXPlaneNormalize(&plD, &plD);
//
//	plN.a = -(mtVP._14 + mtVP._13);
//	plN.b = -(mtVP._24 + mtVP._23);
//	plN.c = -(mtVP._34 + mtVP._33);
//	plN.d = -(mtVP._44 + mtVP._43);
//	D3DXPlaneNormalize(&plN, &plN);
//
//	plF.a = -(mtVP._14 - mtVP._13);
//	plF.b = -(mtVP._24 - mtVP._23);
//	plF.c = -(mtVP._34 - mtVP._33);
//	plF.d = -(mtVP._44 - mtVP._43);
//	D3DXPlaneNormalize(&plF, &plF);
}




