// Implementation of the CMcTree class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


TCHAR *sTxName[] =
{
	"Texture/tree01S.dds",
		"Texture/tree02S.dds",
		"Texture/tree35S.dds",
};



INT	 McUtil_TextureLoad(LPDIRECT3DDEVICE9	pDev
						, TCHAR * sFile
						, LPDIRECT3DTEXTURE9& pTx
						, DWORD color=0xFF000000
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter   = (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN)
{
	if ( FAILED(D3DXCreateTextureFromFileEx(
		pDev
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, color
		, pSrcInfo
		, NULL
		, &pTx
		)) )
	{
		pTx = NULL;
		return -1;
	}
	
	return 0;
}


CMcTree::CMcTree()
{
	m_pDev	= NULL;
	m_iN	= 500;
}

CMcTree::~CMcTree()
{
	Destroy();
}


INT CMcTree::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	INT i=0;

	for(i=0; i<3; ++i)
		McUtil_TextureLoad(m_pDev, sTxName[i], m_pTxTree[i].pTx, 0x00FFFFFF, &m_pTxTree[i].Img);

	m_pBill	= new McBill[m_iN];
	m_pVtx	= new VtxDUV1[m_iN * 6];

	for(i=0; i<m_iN; ++i)
	{
		m_pBill[i].nT = rand()%(3);
		m_pBill[i].vcP.x = 16 + rand()%(32 * 100);
		m_pBill[i].vcP.z = 16 + rand()%(32 * 100);
		m_pBill[i].vcP.y = (rand()%1000 ) * 0.5f;
	}


	return 0;
}


void CMcTree::Destroy()
{
	for(int i=0; i<3; ++i)
		SAFE_RELEASE(	m_pTxTree[i].pTx);

	SAFE_DELETE_ARRAY(	m_pBill	);
	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CMcTree::FrameMove()
{
	INT	i;
	D3DXMATRIX mtB;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtB);

	D3DXMatrixInverse(&mtB, 0, &mtB);

	D3DXVECTOR3 vcCam	= D3DXVECTOR3(mtB._41, mtB._42, mtB._43);
	D3DXVECTOR3 vcZ		= D3DXVECTOR3(mtB._31, mtB._32, mtB._33);

	mtB._41 = 0;
	mtB._42 = 0;
	mtB._43 = 0;

	FLOAT fX;
	FLOAT fY;
	VtxDUV1	Vtx[4];
	D3DXVECTOR3	vcTmp;


	for(i=0; i<m_iN; ++i)
	{
		vcTmp = m_pBill[i].vcP-vcCam;
		m_pBill[i].fZ = D3DXVec3Dot(&vcZ, &vcTmp);
	}

	qsort (m_pBill, m_iN, sizeof(McBill), (int(*) (const void *, const void *)) this->SortFnc);

	for(i=0; i<m_iN; ++i)
	{
		INT	nIdx	= m_pBill[i].nT;

		fX = m_pTxTree[nIdx].Img.Width*.4f;
		fY = m_pTxTree[nIdx].Img.Height*.4f;

		Vtx[0] = VtxDUV1(-fX, fY, 0, 0, 0);
		Vtx[1] = VtxDUV1( fX, fY, 0, 1, 0);
		Vtx[2] = VtxDUV1(-fX,-fY, 0, 0, 1);
		Vtx[3] = VtxDUV1( fX,-fY, 0, 1, 1);

		D3DXVec3TransformCoord(&Vtx[0].p, &Vtx[0].p, &mtB);
		D3DXVec3TransformCoord(&Vtx[1].p, &Vtx[1].p, &mtB);
		D3DXVec3TransformCoord(&Vtx[2].p, &Vtx[2].p, &mtB);
		D3DXVec3TransformCoord(&Vtx[3].p, &Vtx[3].p, &mtB);

		Vtx[0].p += m_pBill[i].vcP;
		Vtx[1].p += m_pBill[i].vcP;
		Vtx[2].p += m_pBill[i].vcP;
		Vtx[3].p += m_pBill[i].vcP;

		Vtx[0].p.y += fY * 1.f;
		Vtx[1].p.y += fY * 1.f;
		Vtx[2].p.y += fY * 1.f;
		Vtx[3].p.y += fY * 1.f;

		m_pVtx[i*6+0] = Vtx[0];
		m_pVtx[i*6+1] = Vtx[1];
		m_pVtx[i*6+2] = Vtx[2];
		m_pVtx[i*6+3] = Vtx[3];
		m_pVtx[i*6+4] = Vtx[2];
		m_pVtx[i*6+5] = Vtx[1];
	}


	return 0;
}


void CMcTree::Render()
{
	INT	i=0;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);



	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	m_pDev->SetFVF(VtxDUV1::FVF);


	for(i=0; i<m_iN; ++i)
	{
		m_pDev->SetTexture(0, m_pTxTree[m_pBill[i].nT].pTx);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2, &m_pVtx[i*6+0], sizeof(VtxDUV1));
	}

//	m_pDev->SetTexture(0, m_pTxTree[0].pTx);
//	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2*m_iN, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

}

