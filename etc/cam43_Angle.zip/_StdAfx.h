#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma once

#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dsound.lib")

#define _WIN32_WINNT			0x0400
#define DIRECTINPUT_VERSION		0x0800

#define STRICT


#include <list>
#include <cstdlib>
#include <ctime>

using namespace std;


#include <windows.h>

#include <windowsx.h>
#include <mmsystem.h>

#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <tchar.h>

#include <D3D9.h>
#include <d3dx9.h>
#include <dxerr9.h>

#include <dinput.h>

#include "D3DUtil.h"
#include "DXUtil.h"

#include "D3DEnum.h"
#include "D3DSetting.h"
#include "D3DApp.h"
#include "resource.h"

#define GMAIN		g_pApp
#define GHINST		g_pApp->m_hInst
#define GHWND		g_pApp->m_hWnd

#define GDEVICE		g_pApp->m_pd3dDevice
#define GSPRITE		g_pApp->m_pd3dSprite
#define GSURFACE	g_pApp->m_pd3dSf

#define GINPUT		g_pApp->m_pInput
#define GCAM		g_pApp->m_pCam

#include "McType.h"
#include "VtxFmt.h"
#include "McUtil.h"

#include "McInput.h"
#include "McCam.h"


#include "McField.h"


#include "Main.h"

#endif