// Implementation of the CMcEffect class.
//
//////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


INT	 McUtil_TextureLoad(LPDIRECT3DDEVICE9	pDev
						, TCHAR * sFile
						, LPDIRECT3DTEXTURE9& pTx
						, DWORD color=0xFF000000
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter   = (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN)
{
	if ( FAILED(D3DXCreateTextureFromFileEx(
		pDev
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, color
		, pSrcInfo
		, NULL
		, &pTx
		)) )
	{
		pTx = NULL;
		return -1;
	}
	
	return 0;
}


CEftExplose::CEftExplose()
{
	m_pDev		= NULL;

	m_pPrt		= NULL;
	m_pVtx		= NULL;
	m_pTx		= NULL;
}

CEftExplose::~CEftExplose()
{
	Destroy();
}


INT CEftExplose::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev	= pDev;

	m_bRn	= FALSE;

	m_iN	= 100;
	m_iVtx = m_iN * 2 * 3;

	m_pPrt	= new EftPt	 [m_iN];
	m_pVtx	= new VtxDUV1[m_iVtx];

	McUtil_TextureLoad(m_pDev, "Texture/Particle.bmp", m_pTx, 0x00FFFFFF);


	for(int i=0; i<m_iN; ++i)
	{
		m_pVtx[i*6 +0].u = 0.f;		m_pVtx[i*6 +0].v = 0.f;
		m_pVtx[i*6 +1].u = 1.f;		m_pVtx[i*6 +1].v = 0.f;
		m_pVtx[i*6 +2].u = 0.f;		m_pVtx[i*6 +2].v = 1.f;
		m_pVtx[i*6 +3].u = 1.f;		m_pVtx[i*6 +3].v = 1.f;
	}

	return 0;
}


void CEftExplose::Destroy()
{
	SAFE_DELETE(	m_pPrt	);
	SAFE_DELETE(	m_pVtx	);

	SAFE_RELEASE(	m_pTx	);
}


INT CEftExplose::FrameMove()
{
	if(g_pApp->m_pInput->KeyDown('R'))
		Set();

	if(!m_bRn)
		return 0;

	INT i;

	for(i=0; i<m_iN; ++i)
	{
		m_pPrt[i].a = -m_pPrt[i].v*0.01f;
		m_pPrt[i].v	+= m_pPrt[i].a;
		m_pPrt[i].p	+= m_pPrt[i].v;
	}

	// for Billboard
	D3DXMATRIX mtView;
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	for(i=0; i<m_iN; ++i)
	{
		D3DXVECTOR3 vcX(mtView._11, mtView._21, mtView._31);
		D3DXVECTOR3 vcY(mtView._12, mtView._22, mtView._32);

		vcX *= m_pPrt[i].fW;
		vcY *= m_pPrt[i].fH;

		m_pVtx[i*6 +0].d = m_pPrt[i].c;
		m_pVtx[i*6 +1].d = m_pPrt[i].c;
		m_pVtx[i*6 +2].d = m_pPrt[i].c;
		m_pVtx[i*6 +3].d = m_pPrt[i].c;

		m_pVtx[i*6 +0].p = m_pPrt[i].p - (vcX - vcY);
		m_pVtx[i*6 +1].p = m_pPrt[i].p + (vcX + vcY);
		m_pVtx[i*6 +2].p = m_pPrt[i].p - (vcX + vcY);
		m_pVtx[i*6 +3].p = m_pPrt[i].p + (vcX - vcY);

		m_pVtx[i*6 +4] = m_pVtx[i*6 + 2];
		m_pVtx[i*6 +5] = m_pVtx[i*6 + 1];
	}

	return 0;
}

void CEftExplose::Set()
{
	m_bRn = !m_bRn;

	if(!m_bRn)
		return;

	for(int i=0; i<m_iN; ++i)
		Reset(i);
}


void CEftExplose::Reset(INT i)
{
	FLOAT fT = D3DXToRadian(rand()%90);
	FLOAT fP = D3DXToRadian(rand()%360);

	FLOAT fV = 4.f;

	m_pPrt[i].p		= D3DXVECTOR3(0,0,0);
	m_pPrt[i].a		= D3DXVECTOR3(0,0,0);

	m_pPrt[i].v.x	= fV * sinf(fT) * sinf(fP);
	m_pPrt[i].v.y	= fV * cosf(fT);
	m_pPrt[i].v.z	= fV * sinf(fT) * cosf(fP);

	m_pPrt[i].a		= -m_pPrt[i].v * 0.01f;


	m_pPrt[i].c		= D3DXCOLOR( (6+rand()%5)/10.f, (6+rand()%5)/10.f, (6+rand()%5)/10.f, 1.f);
	m_pPrt[i].fW = 100.f;
	m_pPrt[i].fH = 100.f;

	m_pPrt[i].bLive = TRUE;
}

void CEftExplose::Render()
{
	if(!m_bRn)
		return;

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );

	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCCOLOR);
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_DESTALPHA );

	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetFVF(VtxDUV1::FVF);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iN * 2, m_pVtx, sizeof(VtxDUV1));

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE,  TRUE);
}