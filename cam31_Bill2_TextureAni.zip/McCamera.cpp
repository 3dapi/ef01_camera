// Implementation of the CMcCamera class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCamera::CMcCamera()
{
	m_pDev	= NULL;
}

CMcCamera::~CMcCamera()
{

}


INT CMcCamera::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev		= pDev;

	m_vcEye		= D3DXVECTOR3(100,150,-600);
	m_vcLook	= D3DXVECTOR3(100,10,0);
	m_vcUp		= D3DXVECTOR3(0,1,0);

	D3DXMatrixPerspectiveFovLH(&m_mtPrj,D3DX_PI/4.f, 800.f/600.f, 1.f, 5000.f);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	return 0;
}


INT CMcCamera::FrameMove()
{
	D3DXVECTOR3 vcDelta = g_pApp->m_pInput->GetMouseEps();

	if(vcDelta.z !=0.f)
		MoveForward(-vcDelta.z* 1.f, 1.f);

	if(g_pApp->m_pInput->KeyState('W'))
		MoveForward( 15.f, 1.f);

	if(g_pApp->m_pInput->KeyState('S'))
		MoveForward(-15.f, 1.f);

	if(g_pApp->m_pInput->KeyState('A'))
		MoveSideward(-15.f);

	if(g_pApp->m_pInput->KeyState('D'))
		MoveSideward(15.f);

	if(g_pApp->m_pInput->BtnState(1))
		Rotate(&vcDelta, .2f);

	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);

	return 0;
}

void CMcCamera::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamera::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	D3DXVECTOR3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamera::Rotate(const D3DXVECTOR3* vcDelta, float fSpeed)
{
	D3DXVECTOR3 vcEps = *vcDelta;

	FLOAT	fYaw	;
	FLOAT	fPitch	;

	D3DXVECTOR3 vcZ;
	D3DXVECTOR3 vcY;
	D3DXVECTOR3 vcX;

	D3DXMATRIX rtY;
	D3DXMATRIX rtX;

	// ���� ��ǥ y �࿡ ���� ȸ��
	fYaw	= D3DXToRadian(vcEps.x * fSpeed);
	D3DXMatrixRotationY(&rtY, fYaw);

	vcZ = m_vcLook-m_vcEye;
	vcY = D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);

	D3DXVec3TransformCoord(&vcZ, &vcZ, &rtY);
	D3DXVec3TransformCoord(&vcY, &vcY, &rtY);

	m_vcLook= vcZ + m_vcEye;
	m_vcUp	= vcY;
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);


	// ī�޶��� x �࿡ ���� ȸ��
	fPitch	= D3DXToRadian(vcEps.y * fSpeed);
	vcX	= D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
	vcY = D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);
	vcZ = m_vcLook-m_vcEye;

	D3DXMatrixRotationAxis(&rtX, &vcX, fPitch);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rtX);
	D3DXVec3TransformCoord(&vcY, &vcY, &rtX);

	m_vcLook= vcZ + m_vcEye;
	m_vcUp	= vcY;
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}