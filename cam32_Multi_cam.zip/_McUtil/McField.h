// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

class CMcField
{
public:
	struct VtxNDUV2
	{
		D3DXVECTOR3	p;
		D3DXVECTOR3	n;
		DWORD		d;
		FLOAT		u0,v0;
		FLOAT		u1,v1;

		VtxNDUV2()	{}
		VtxNDUV2(FLOAT X,FLOAT Y,FLOAT Z,FLOAT nX,FLOAT nY,FLOAT nZ
			,FLOAT U0,FLOAT V0,FLOAT U1,FLOAT V1
			, DWORD D=0xFFFFFFFF):p(X,Y,Z),n(nX,nY,nZ)
			,u0(U0),v0(V0)
			,u1(U1),v1(V1)
			, d(D){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX2),};
	};




	struct VtxIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		VtxIdx()							{	a = 0;	  b = 1;		 c = 2;	}
		VtxIdx(WORD A, WORD B, WORD C)		{	a = A;    b = B;		 c = C;	}
		VtxIdx(WORD* R)						{	a = R[0]; b = R[1];	 c = R[2];	}
		operator WORD* ()					{		return (WORD *) &a;			}
		operator CONST WORD* () const		{		return (CONST WORD *) &a;	}
	};


protected:
	LPDIRECT3DDEVICE9	m_pDev;
	
	INT				m_iN;														// Number of tile for Width
	INT				m_iW;														// Width of tile for x;

	INT				m_iNvx;														// Vertex Number
	INT				m_iNix;														// Index Number
	INT				m_iVxS;														// Vertex Size
	DWORD			m_dFVF;


public:
	VtxNDUV2*			m_pVtx;
	VtxIdx*				m_pIdx;
	LPDIRECT3DTEXTURE9	m_pTx0;
	LPDIRECT3DTEXTURE9	m_pTx1;

	FLOAT				m_fAl;
	D3DXVECTOR3			m_vcLgt;
	D3DLIGHT9			m_light;
	D3DMATERIAL9		m_mtl;
	
public:
	CMcField();
	~CMcField();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
	
protected:
	void	NormalSet();
	D3DXVECTOR3	NormalVec(int z, int x);

	INT		MapLoad();
};

#endif


