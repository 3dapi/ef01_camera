// Interface for the CMcCamT class.
// 3rd Person Camera
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCAMT_H_
#define _MCCAMT_H_


class CMcCamT : public CMcCam
{
protected:
	D3DXVECTOR3		m_vcBasis;			// Look Pos
	FLOAT			m_fEpslnY;			// Epsilon Y
	FLOAT			m_fGap;				// Distance Between Camera and Basis
public:
	CMcCamT();
	virtual ~CMcCamT();

	virtual INT	Create(LPDIRECT3DDEVICE9 pDev);
	virtual INT	FrameMove();

	void		SetBasis(D3DXVECTOR3 _vcP)	{	m_vcBasis =_vcP;	}
	D3DXVECTOR3	GetBasis()					{	return m_vcBasis;	}

	void		SetEpsilonY(FLOAT _fY)		{	m_fEpslnY =_fY;		}
	FLOAT		GetEpsilonY()				{	return m_fEpslnY;	}

	void		SetGap(FLOAT _fG)			{	m_fGap =_fG;		}
	FLOAT		GetGap()					{	return m_fGap;		}

protected:
	void		MoveSideward(FLOAT	fSpeed);
	void		MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
};

#endif