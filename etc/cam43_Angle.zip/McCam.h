// Interface for the CMcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_

class CMcCam
{
public:
	D3DXMATRIX		m_mtViw;													// View Matrix
	D3DXMATRIX		m_mtPrj;													// Projection Matrix

	D3DXVECTOR3		m_vcEye;													// Camera position
	D3DXVECTOR3		m_vcLook;													// Look vector

	FLOAT			m_fPhi;
	FLOAT			m_fThe;

	D3DXVECTOR3		m_vcAxsX;
	D3DXVECTOR3		m_vcAxsY;
	D3DXVECTOR3		m_vcAxsZ;
	
public:
	CMcCam();
	~CMcCam();

	INT		Init();
	INT		FrameMove();

	D3DXMATRIX	GetViewMatrix()	{	return m_mtViw;	}

protected:
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	void	MoveSideward(FLOAT	fSpeed);

	void	SetupViewMatrix();
	
};

#endif
