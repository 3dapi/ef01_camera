// Implementation of the CMcEftTex class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


mpTex*	CMcEftTex::LstTex = NULL;


CMcEftTex::CMcEftTex()
{
	m_pDev =	NULL;

	m_vcPos	= D3DXVECTOR3(0.f, 0.f, 0.f);
	m_vcScl	= D3DXVECTOR3(1.f, 1.f, 1.f);


	m_pTex	= NULL;
	m_dTimeInt	= 0;
	m_nTexTotal	= 0;
	m_nTex		= 0;
}


CMcEftTex::~CMcEftTex()
{
	Destroy();
}


INT	CMcEftTex::Create(char* sPath, char* sFile, LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	float	fScl = 1;
	
	m_pVtx[0]=	CMcEftTex::VtxDUV1(-fScl, -fScl, 0, 0, 1, 0x66FFFFFF);
	m_pVtx[1]=	CMcEftTex::VtxDUV1(-fScl,  fScl, 0, 0, 0, 0x66FFFFFF);
	m_pVtx[2]=	CMcEftTex::VtxDUV1( fScl,  fScl, 0, 1, 0, 0x66FFFFFF);
	m_pVtx[3]=	CMcEftTex::VtxDUV1( fScl, -fScl, 0, 1, 1, 0x66FFFFFF);

	m_vcPos	=	D3DXVECTOR3(33.f, 10.f, 10.f);


	if(NULL == LstTex)
		LstTex = new mpTex;


	char	sFullPath[MAX_PATH];
	sprintf(sFullPath, "%s/%s", sPath, sFile);
	
	
	FILE*	fp=NULL;
	fp = fopen(sFullPath, "rt");

	if(!fp)
		return -1;

	char	sLine[256];

	fgets(sLine, 256, fp);	sscanf(sLine, "%f %f", &m_vcScl.x, &m_vcScl.y);
	fgets(sLine, 256, fp);	sscanf(sLine, "%ld", &m_dTimeInt);
	fgets(sLine, 256, fp);	sscanf(sLine, "%d", &m_nTexTotal);

	m_pTex = new LPDIRECT3DTEXTURE9[m_nTexTotal];
	
	while (!feof(fp))
	{
		fgets(sLine, 256, fp);

		LPDIRECT3DTEXTURE9	pTex;
		char	sFile[256]={0};
		char	sTex[256]={0};
		int		nIdx=0;

		sscanf(sLine, "%d %s", &nIdx, sFile);

		char* pL = sLine + strlen(sLine)-1;

		if( '\n' == *pL ||'\r' == *pL)
			*pL = 0;

		sprintf(sTex, "%s/%s", sPath, sFile);


		mpTex::iterator it;

		it = LstTex->find(sTex);

		if(it == LstTex->end())
		{
			D3DXCreateTextureFromFileEx(m_pDev
									, sTex
									, D3DX_DEFAULT
									, D3DX_DEFAULT
									, D3DX_DEFAULT
									, 0
									, D3DFMT_UNKNOWN
									, D3DPOOL_MANAGED
									, D3DX_DEFAULT
									, D3DX_DEFAULT
									, 0xFF000000
									, NULL
									, NULL
									, &pTex);

			LstTex->insert(mpTex::value_type(sTex, pTex));
		}
		else
			pTex = (LPDIRECT3DTEXTURE9)it->second;

		m_pTex[nIdx] = pTex;

		if((nIdx+1) == m_nTexTotal)
			break;
	}

	fclose(fp);


	m_dTimeBgn = timeGetTime();

	return S_OK;
}

void CMcEftTex::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pTex	);
}


INT CMcEftTex::FrameMove()
{
	D3DXMATRIX	mtScl;
	D3DXMATRIX	mtBill;
	D3DXMATRIX	mtWorld;
	D3DXMATRIX	mtView;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	D3DXMatrixInverse(&mtBill, NULL, &mtView);
	D3DXMatrixScaling(&mtScl, m_vcScl.x, m_vcScl.y, m_vcScl.z);

	
	mtBill._41 = 0;
	mtBill._42 = 0;
	mtBill._43 = 0;
	
	m_mtWorld = mtScl * mtBill;
	m_mtWorld._41 = m_vcPos.x;
	m_mtWorld._42 = m_vcPos.y;
	m_mtWorld._43 = m_vcPos.z;

	DWORD	dTimeCur = timeGetTime();

	if( dTimeCur >= (m_dTimeBgn + m_dTimeInt))
	{
		++m_nTex;
		m_nTex %= m_nTexTotal;

		m_dTimeBgn = dTimeCur;
	}


	return 0;
}


void CMcEftTex::Render()
{
	static D3DXMATRIX	mtI(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
	m_pDev->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtWorld);

	m_pDev->SetTexture(0, m_pTex[m_nTex]);
	m_pDev->SetTexture(1, NULL);
	m_pDev->SetFVF(CMcEftTex::VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof (CMcEftTex::VtxDUV1));



	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	
}


void CMcEftTex::SetPosition(D3DXVECTOR3	vcPos)
{
	m_vcPos = vcPos;
}