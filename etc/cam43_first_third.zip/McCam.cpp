// Implementation of the CMcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCam::CMcCam()
{
	m_pDev	= NULL;

	
	strcpy(m_sName, "MC_DEFAULT_CAMERA");
	m_eType	= MC_CAM_1;
	
	D3DXMatrixIdentity(&m_mtViw);
	D3DXMatrixIdentity(&m_mtVwI);
	D3DXMatrixIdentity(&m_mtBil);

	D3DXMatrixIdentity(&m_mtPrj);
	

	m_vcEye		= D3DXVECTOR3(0,0,-1);													// Camera position
	m_vcLook	= D3DXVECTOR3(0,0, 0);													// Look vector
	m_vcUp		= D3DXVECTOR3(0,1, 0);														// up vector

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;

	m_fFov		= D3DX_PI/4.f;
	m_fAsp		= 800.f/600.f;
	m_fNr		= 1.f;
	m_fFr		= 10000.f;
}

CMcCam::~CMcCam()
{

}



void CMcCam::UpdateViewProj()
{
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, m_fFov, m_fAsp, m_fNr, m_fFr);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	D3DXMatrixInverse(&m_mtVwI, NULL, &m_mtViw);
	m_mtBil = m_mtVwI;
	m_mtBil._41 = 0.f;
	m_mtBil._42 = 0.f;
	m_mtBil._43 = 0.f;


	m_vcAxisX	= D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
	m_vcAxisY	= D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);
	m_vcAxisZ	= D3DXVECTOR3(m_mtViw._13, m_mtViw._23, m_mtViw._33);
}