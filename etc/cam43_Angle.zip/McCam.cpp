// Implementation of the CMcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCam::CMcCam()
{

}

CMcCam::~CMcCam()
{

}


INT CMcCam::Init()
{
	m_fPhi		= 90.f;
	m_fThe		= 120.f;
	m_vcEye		= VEC3(0,500, -200);
	m_vcLook	= VEC3(0,0,0);
	
	D3DXMatrixPerspectiveFovLH(&m_mtPrj,D3DX_PI/4.f, 800.f/600.f, 1.f, 15000.f);
	SetupViewMatrix();

	return 0;
}


INT CMcCam::FrameMove()
{
	// Wheel mouse...
	VEC3 vcDelta = g_pApp->m_pInput->GetMouseDelta();

	if(vcDelta.z !=0.f)
	{
		MoveForward(-vcDelta.z* .1f, 1.f);
	}

	if(g_pApp->m_pInput->KeyState(DIK_W))
	{
		MoveForward( 4.f, 1.f);
	}

	if(g_pApp->m_pInput->KeyState(DIK_S))
	{
		MoveForward(-4.f, 1.f);
	}


	if(g_pApp->m_pInput->KeyState(DIK_A))
	{
		MoveSideward(-4.f);
	}

	if(g_pApp->m_pInput->KeyState(DIK_D))
	{
		MoveSideward(4.f);
	}


	if(g_pApp->m_pInput->GetMouseSt(1))
	{
		m_fPhi	+= vcDelta.x * 0.1f;
		m_fThe	+= vcDelta.y * 0.1f;
	}

	SetupViewMatrix();

	g_pApp->m_pd3dDevice->SetTransform(D3DTS_VIEW, &m_mtViw);
	g_pApp->m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &m_mtPrj);


	return 0;
}


void CMcCam::SetupViewMatrix()
{
	if(m_fThe >=  360)	m_fThe -= 360;
	if(m_fThe <= -360)	m_fThe += 360;
	if(m_fPhi >=  360)	m_fPhi -= 360;
	if(m_fPhi <= -360)	m_fPhi += 360;

	float	fTh	= D3DXToRadian(m_fThe);
	float	fPh	= D3DXToRadian(m_fPhi);

	m_vcLook.y	= cosf(fTh);
	m_vcLook.x	= sinf(fTh) * cosf(fPh);
	m_vcLook.z	= sinf(fTh) * sinf(fPh);

	D3DXVECTOR3	vcUp(0,1,0);

	if(0 == m_fThe || 180 == fabsf(m_fThe) )
	{
		m_vcAxsX = D3DXVECTOR3(1, 0, 0);
		D3DXVec3Normalize(&m_vcAxsX, &m_vcAxsX);

		D3DXVec3Cross(&m_vcAxsY, &m_vcLook, &m_vcAxsX);
	}
	else if( (0< m_fThe && m_fThe <180))
	{
		D3DXVec3Cross(&m_vcAxsX, &vcUp, &m_vcLook);
		D3DXVec3Normalize(&m_vcAxsX, &m_vcAxsX);

		D3DXVec3Cross(&m_vcAxsY, &m_vcLook, &m_vcAxsX);
	}
	else
	{
		D3DXVec3Cross(&m_vcAxsX, &m_vcLook, &vcUp);
		D3DXVec3Normalize(&m_vcAxsX, &m_vcAxsX);

		D3DXVec3Cross(&m_vcAxsY, &m_vcLook, &m_vcAxsX);
	}

	m_mtViw = D3DXMATRIX( m_vcAxsX.x, m_vcAxsY.x, m_vcLook.x, 0
						, m_vcAxsX.y, m_vcAxsY.y, m_vcLook.y, 0
						, m_vcAxsX.z, m_vcAxsY.z, m_vcLook.z, 0

						, -D3DXVec3Dot(&m_vcAxsX, &m_vcEye)
						, -D3DXVec3Dot(&m_vcAxsY, &m_vcEye)
						, -D3DXVec3Dot(&m_vcLook, &m_vcEye)
						,  1
						);

	m_vcLook += m_vcEye;
}

void CMcCam::MoveSideward(FLOAT fSpeed)
{
	VEC3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);
	m_vcEye  += tmp * fSpeed;
}


void CMcCam::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	VEC3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
}