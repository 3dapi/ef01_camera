// Implementation of the CMcCamManager class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCamManager::CMcCamManager()
{
	m_pCam0		= NULL;
	m_pCam1		= NULL;
	m_pCam2		= NULL;
	m_pCam3		= NULL;
	m_pCam4		= NULL;
}

CMcCamManager::~CMcCamManager()
{
	Destroy();
}


INT CMcCamManager::Create(LPDIRECT3DDEVICE9 pDev)
{
	SAFE_NEWCREATE1(	m_pCam0,	CMcCamera	, pDev	);
	SAFE_NEWCREATE1(	m_pCam1,	CMcCamera	, pDev	);
	SAFE_NEWCREATE1(	m_pCam2,	CMcCamera	, pDev	);
	SAFE_NEWCREATE1(	m_pCam3,	CMcCamera	, pDev	);
	SAFE_NEWCREATE1(	m_pCam4,	CMcCamera	, pDev	);

	return 0;
}


void CMcCamManager::Destroy()
{
	SAFE_DELETE(	m_pCam0		);
	SAFE_DELETE(	m_pCam1		);
	SAFE_DELETE(	m_pCam2		);
	SAFE_DELETE(	m_pCam3		);
	SAFE_DELETE(	m_pCam4		);
}

INT CMcCamManager::FrameMove()
{
	SAFE_FRMOV(	m_pCam0		);

	m_pCam0->UpdateViewProj();

	D3DXVECTOR3	vcEye	= m_pCam0->GetEye();
	D3DXVECTOR3	vcLook	= m_pCam0->GetLook();
	D3DXVECTOR3	vcUp	= m_pCam0->GetUP();

	D3DXVECTOR3	vcAxisX = m_pCam0->GetAxisX();
	D3DXVECTOR3	vcAxisY = m_pCam0->GetAxisY();
	D3DXVECTOR3	vcAxisZ = m_pCam0->GetAxisZ();


	m_pCam1->SetParamView(vcEye, vcEye - 100.f * vcAxisX,	D3DXVECTOR3(0,1,0));
	m_pCam2->SetParamView(vcEye, vcEye + 100.f * vcAxisX,	D3DXVECTOR3(0,1,0));
	m_pCam3->SetParamView(vcEye + 300.f * vcAxisY, vcEye,	vcUp);
	m_pCam4->SetParamView(vcEye, vcEye - 100.f * vcAxisZ,	D3DXVECTOR3(0,1,0));

	m_pCam1->UpdateViewProj();
	m_pCam2->UpdateViewProj();
	m_pCam3->UpdateViewProj();
	m_pCam4->UpdateViewProj();

	return 0;
}