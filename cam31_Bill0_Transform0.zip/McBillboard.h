// Interface for the CMcBillboard class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McBillboard_H_
#define _McBillboard_H_


class CMcBillboard  
{
public:
	struct VtxUV1
	{
		D3DXVECTOR3	p;
		FLOAT		u,v;
		
		VtxUV1()	{}
		VtxUV1(	FLOAT X,FLOAT Y,FLOAT Z
			,	FLOAT U,FLOAT V):p(X,Y,Z)
			,	u(U),v(V){}
		enum	{FVF = ((D3DFVF_XYZ|D3DFVF_TEX1)),};
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;

	LPDIRECT3DTEXTURE9	m_pTex;
	D3DXIMAGE_INFO		m_pImg;
	
	D3DXVECTOR3			m_vcPos;
	VtxUV1				m_pVtx[4];
	
public:
	CMcBillboard();
	virtual ~CMcBillboard();
	
	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif