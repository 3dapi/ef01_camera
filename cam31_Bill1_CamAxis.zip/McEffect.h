// Interface for the CMcEffect class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCEFFECT_H_
#define _MCEFFECT_H_


class CEftExplose
{
public:
	struct VtxDUV1
	{
		D3DXVECTOR3	p;
		DWORD		d;
		FLOAT		u,v;
		

		VtxDUV1()	{}
		VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT U,FLOAT V
			, DWORD D=0xFFFFFFFF):p(X,Y,Z)
				,u(U),v(V)
				,d(D){}
		enum	{FVF = ((D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)),};
	};


	struct EftPt																	// Particle structure
	{
		D3DXVECTOR3	p;																// Position
		D3DXVECTOR3	v;																// Velocity
		D3DXVECTOR3	a;																// Acceleration
		D3DXCOLOR	c;																// Color
		
		BOOL	bLive;																// Active (Yes/No)
		FLOAT	fLife;																// Ptc fLife
		FLOAT	fFade;																// Fade Speed
		
		FLOAT	fW;			// width
		FLOAT	fH;			// height
		
		EftPt()
		{
			p.x=0.f;	p.y=0.f;	p.z=0.f;
			v.x=0.f;	v.y=0.f;	v.z=0.f;
			a.x=0.f;	a.y=0.f;	a.z=0.f;
			c.r=1.f;	c.g=1.f;	c.b=1.f;	c.a= 1.f;
			
			bLive= TRUE;
			fLife=0.f;
			fFade=0.f;
			fW=.5f;
			fH=.5f;
		}
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;
	BOOL				m_bRn;													// rendering?
	
	INT					m_iN;													// Particle Number
	EftPt*				m_pPrt;													// Particle pointer

	INT					m_iVtx;													// Vertex Number
	VtxDUV1*			m_pVtx;													// Vertex
	LPDIRECT3DTEXTURE9	m_pTx;													// Texture

public:
	CEftExplose();
	virtual ~CEftExplose();

	INT		Create(LPDIRECT3DDEVICE9);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	Set();
	void	Reset(int i);
};

#endif
