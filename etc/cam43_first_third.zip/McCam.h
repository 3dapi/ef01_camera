// Interface for the CMcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_

enum EMcCamera
{
	MC_CAM_1,
	MC_CAM_3,
};

typedef D3DVIEWPORT9	DVIEWPORT;

class CMcCam
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	char			m_sName[128];												// Camera Name
	EMcCamera		m_eType;													// Camera Type
	
	D3DXMATRIX		m_mtViw;													// View Matrix
	D3DXMATRIX		m_mtVwI;													// Inverse View Matrix
	D3DXMATRIX		m_mtBil;													// Billboard Matrix

	D3DXMATRIX		m_mtPrj;													// Projection Matrix
	

	// For View Matrix
	D3DXVECTOR3		m_vcEye;													// Camera position
	D3DXVECTOR3		m_vcLook;													// Look vector
	D3DXVECTOR3		m_vcUp;														// up vector

	FLOAT			m_fYaw;
	FLOAT			m_fPitch;


	// Camera Axis
	D3DXVECTOR3		m_vcAxisX;
	D3DXVECTOR3		m_vcAxisY;
	D3DXVECTOR3		m_vcAxisZ;


	// For Projection Matrix
	FLOAT			m_fFov;														// Field of View
	FLOAT			m_fAsp;														// Aspect
	FLOAT			m_fNr;														// Near
	FLOAT			m_fFr;														// Far

	// For Viewport
	D3DVIEWPORT9	m_VP;														// View Port
	
public:
	CMcCam();
	virtual ~CMcCam();

	void		SetName(char* sName)	{	strcpy(m_sName, sName);			}
	char*		GetName()				{	return m_sName;					}

	void		SetType(INT	eType)		{	m_eType = EMcCamera(eType);		}
	EMcCamera	GetType()				{	return m_eType;					}

	D3DXMATRIX	GetMatrixView()			{	return m_mtViw;		}
	D3DXMATRIX	GetMatrixViewI()		{	return m_mtVwI;		}
	D3DXMATRIX	GetMatrixBill()			{	return m_mtBil;		}

	D3DXMATRIX	GetMatrixProj()			{	return m_mtPrj;		}

	
	
	D3DXVECTOR3	GetEye()				{	return m_vcEye;		}
	D3DXVECTOR3	GetLook()				{	return m_vcLook;	}
	D3DXVECTOR3 GetUP()					{	return m_vcUp;		}

	FLOAT		GetYaw()				{	return m_fYaw;		}
	FLOAT		GetPitch()				{	return m_fPitch;	}


	D3DXVECTOR3	GetAxisX()				{	return m_vcAxisX;	}
	D3DXVECTOR3	GetAxisY()				{	return m_vcAxisY;	}
	D3DXVECTOR3	GetAxisZ()				{	return m_vcAxisZ;	}


	void		SetFov(FLOAT _fFov)		{	m_fFov = _fFov;		}
	FLOAT		GetFov()				{	return m_fFov;		}

	void		SetAspect(FLOAT _fAsp)	{	m_fAsp = _fAsp;		}
	FLOAT		GetAspect()				{	return m_fAsp;		}

	void		SetNear(FLOAT _fNear)	{	m_fNr  = _fNear;	}
	FLOAT		GetNear()				{	return m_fNr;		}

	void		SetFar(FLOAT _fFar)		{	m_fFr  = _fFar;		}
	FLOAT		GetFar()				{	return m_fFr;		}


	void		SetViewport(DVIEWPORT _v){	m_VP   = _v;		}
	DVIEWPORT	GetViewport()			{	return m_VP;		}

	void		SetParamView(	D3DXVECTOR3 vcEye
							,	D3DXVECTOR3 vcLook
							,	D3DXVECTOR3 vcUp)
	{
		m_vcEye		= vcEye;
		m_vcLook	= vcLook;
		m_vcUp		= vcUp;
	}

	void		SetParamProjection(FLOAT fFov,FLOAT fAsp,FLOAT fNear,FLOAT fFar)
	{
		m_fFov	= fFov;
		m_fAsp	= fAsp;
		m_fNr	= fNear;
		m_fFr	= fFar;
	}
	

	void		UpdateViewProj();

public:
	virtual INT	Create(LPDIRECT3DDEVICE9 pDev)	{	return 0;	}
	virtual INT	FrameMove()						{	return 0;	}
};

#endif
