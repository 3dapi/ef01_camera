// Implementation of the CMcCamT class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcCamT::CMcCamT()
{
	strcpy(m_sName, "MC_3rd_CAMERA");
	m_eType		= MC_CAM_3;

	m_vcBasis	= D3DXVECTOR3( 0, 0, 0);
	m_fEpslnY	=  20.f;
	m_fGap		= 100.f;
}

CMcCamT::~CMcCamT()
{

}


INT CMcCamT::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev		= pDev;

	m_vcBasis	= D3DXVECTOR3( 60, 50, 60);
	m_fYaw		= D3DXToRadian(60.f);

	D3DXVECTOR3	vcR( cosf(m_fYaw), 0, sinf(m_fYaw));

	vcR			*=m_fGap;

	D3DXVECTOR3 vcLook	= m_vcBasis + D3DXVECTOR3(0, m_fEpslnY, 0);
	D3DXVECTOR3 vcEye	= m_vcBasis + vcR;

	SetParamView(vcEye, vcLook, D3DXVECTOR3(0,1,0));

	return 0;
}


INT CMcCamT::FrameMove()
{
	// Wheel mouse...
	D3DXVECTOR3 vcD = g_pApp->m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
	{
		MoveForward(-vcD.z* .5f, 1.f);
	}

	if(g_pApp->m_pInput->KeyState('W'))					// W
	{
		MoveForward( 4.f, 1.f);
	}

	if(g_pApp->m_pInput->KeyState('S'))					// S
	{
		MoveForward(-4.f, 1.f);
	}


	if(g_pApp->m_pInput->KeyState('A'))					// A
	{
		MoveSideward(-4.f);
	}

	if(g_pApp->m_pInput->KeyState('D'))					// D
	{
		MoveSideward(4.f);
	}

	if(g_pApp->m_pInput->BtnState(1))
	{
		D3DXVECTOR3	vcDelta = g_pApp->m_pInput->GetMouseEps();
		m_fYaw	= D3DXToRadian(vcDelta.x * 0.1f);
		m_fPitch= D3DXToRadian(vcDelta.y * 0.1f);

		D3DXMATRIX rot;
		D3DXVECTOR3 vcR = m_vcEye - m_vcLook;
		D3DXVECTOR3 vcX;

		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcR, &vcR, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcEye		= m_vcLook + vcR;

		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

		vcR = m_vcEye - m_vcLook;
		vcX =D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);

		D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
		D3DXVec3TransformCoord(&vcR, &vcR, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcEye		= m_vcLook + vcR;
	}




	UpdateViewProj();

	g_pApp->m_pd3dDevice->SetTransform(D3DTS_VIEW, &m_mtViw);
	g_pApp->m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &m_mtPrj);

	return 0;
}

void CMcCamT::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcBasis+= tmp * fSpeed;
	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamT::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	D3DXVECTOR3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcBasis+= tmp * fSpeed;
	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}
