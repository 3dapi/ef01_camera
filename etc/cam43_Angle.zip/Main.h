// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _Main_H_
#define _Main_H_

struct VtxUV1
{
	D3DXVECTOR3	p;
	FLOAT		tU, tV;

	VtxUV1()	{}
	VtxUV1(FLOAT X, FLOAT Y, FLOAT Z, FLOAT U, FLOAT V)
	{
		p.x = X;
		p.y = Y;
		p.z = Z;
		tU	= U;
		tV	= V;
	}

	enum {FVF =(D3DFVF_XYZ|D3DFVF_TEX1), };
};


class CMain : public CD3DApplication
{
public:
	ID3DXFont*			m_pD3DXFont	;											// D3DX font
	CMcInput*			m_pInput	;
	CMcCam*				m_pCam		;
	
	CMcField*			m_pField	;
	LPDIRECT3DTEXTURE9		m_pTex			;
	VtxUV1					m_pVtx[4]		;
	
public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
	CMain();
};


extern CMain*		g_pApp;


#endif