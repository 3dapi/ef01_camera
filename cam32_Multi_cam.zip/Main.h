#ifndef _MAIN_H_
#define _MAIN_H_



struct McRndSf
{
	LPDIRECT3DTEXTURE9	pTx;
	LPDIRECT3DSURFACE9	pSf;

	McRndSf()
	{
		pTx	= NULL;
		pSf	= NULL;
	}

	void Invalidate()
	{
		SAFE_RELEASE(	pTx	);
		SAFE_RELEASE(	pSf	);
	}
};


class CMain : public CD3DApplication
{
public:
	ID3DXFont*		m_pD3DXFont	;												// D3DX font

	CMcInput*		m_pInput	;
	CMcGrid*		m_pGrid		;

	CMcCamManager*	m_pCamMn	;
	CMcField*		m_pField	;
	
	LPDIRECT3DSURFACE9	m_pCurBck	;												// Back Buffer
	LPDIRECT3DSURFACE9	m_pCurDpt	;												// Surface

	McRndSf			m_RndSf[4]	;

	INT				m_iTxW		;												// Texture Size


public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	
	
public:
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	CMain();
};


extern CMain*	g_pApp;


#endif