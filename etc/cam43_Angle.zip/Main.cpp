// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pField		= NULL;
}


HRESULT CMain::Init()
{
	SAFE_NEWINIT(	m_pInput,	CMcInput	);
	SAFE_NEWINIT(	m_pCam,		CMcCam		);
	SAFE_NEWINIT(	m_pField,	CMcField	);

	D3DXFONT_DESC hFont =
	{
		20, 0, FW_BOLD, 1, 0
		,	ANSI_CHARSET, OUT_DEFAULT_PRECIS
		,	ANTIALIASED_QUALITY, FF_DONTCARE, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;




	m_pVtx[0]	= VtxUV1(-500.f, 0.f, -500.f, 0.f, 1.f);
	m_pVtx[1]	= VtxUV1(-500.f, 0.f,  500.f, 0.f, 0.f);
	m_pVtx[2]	= VtxUV1( 500.f, 0.f,  500.f, 1.f, 0.f);
	m_pVtx[3]	= VtxUV1( 500.f, 0.f, -500.f, 1.f, 1.f);

	D3DXCreateTextureFromFile(m_pd3dDevice, "Texture/env3.bmp", &m_pTex);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pField	);

	SAFE_RELEASE( m_pD3DXFont );

	SAFE_RELEASE(	m_pTex		);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	
	return S_OK;
}



HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCam		);

	return S_OK;
}




HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	SAFE_RENDER(	m_pField	);


	m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pd3dDevice->SetTexture(0, m_pTex);
	m_pd3dDevice->SetFVF(VtxUV1::FVF);
	m_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1));

	RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}



HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	TCHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;
	
	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );


	rc.top = 23;
	rc.bottom = rc.top + 20;
	
	sprintf(szMsg, "Camera: %f %f %f %f", m_pCam->m_fThe
										, m_pCam->m_vcAxsX.x
										, m_pCam->m_vcAxsX.y
										, m_pCam->m_vcAxsX.z );

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1) );

	
	return S_OK;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}