// Interface for the CMcEftTex class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _McEftTex_H_
#define _McEftTex_H_

#include <map>
#include <string>


typedef std::map<std::string, void*>	mpTex;


class CMcEftTex  
{
public:	
	struct VtxDUV1
	{
		D3DXVECTOR3	p;
		DWORD		d;
		FLOAT		u, v;

		enum	{FVF = D3DFVF_XYZ| D3DFVF_DIFFUSE|D3DFVF_TEX1};

		VtxDUV1() : p(0,0,0), u(0), v(0), d(0xFFFFFF){}
		VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
				,FLOAT U,FLOAT V
				, DWORD D=0xFFFFFFFF) : p(X,Y,Z), u(U), v(V), d(D){}
	};


protected:
	LPDIRECT3DDEVICE9	m_pDev	;
	D3DXVECTOR3			m_vcPos	;
	D3DXVECTOR3			m_vcScl	;

	D3DXMATRIX			m_mtWorld;

	LPDIRECT3DTEXTURE9*	m_pTex	;
	VtxDUV1				m_pVtx[4];

	DWORD				m_dTimeInt;
	DWORD				m_dTimeBgn;
	INT					m_nTexTotal;
	INT					m_nTex;


public:
	CMcEftTex();
	virtual ~CMcEftTex();

	INT		Create(char* sPath, char* sFile, LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetPosition(D3DXVECTOR3	vcPos);

public:
	static mpTex*	LstTex;
};




#endif 
