

#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont	= NULL;
	m_pInput	= NULL;
	m_pGrid		= NULL;

	m_pCamMn	= NULL;
	m_pField	= NULL;

	m_iTxW		= 180;

	m_pCurBck	= NULL;
	m_pCurDpt	= NULL;

	memset(m_RndSf, 0, sizeof(m_RndSf));
}


HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(m_pInput , CMcInput		, m_hWnd);
	SAFE_NEWCREATE1(m_pGrid	 , CMcGrid		, m_pd3dDevice);

	SAFE_NEWCREATE1(m_pCamMn,	CMcCamManager, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pField,	CMcField	, m_pd3dDevice);

	
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;

	return S_OK;
}



HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pCamMn	);
	SAFE_DELETE(	m_pField	);

	return S_OK;
}



HRESULT CMain::Restore()
{
	HRESULT hr;
	
	if(m_pD3DXFont)
		m_pD3DXFont->OnResetDevice();


	for(int i=0; i<4; ++i)
	{
		hr = m_pd3dDevice->CreateTexture(m_iTxW, m_iTxW, 1
			, D3DUSAGE_RENDERTARGET
			, D3DFMT_X8R8G8B8
			, D3DPOOL_DEFAULT
			, &m_RndSf[i].pTx, NULL);

		m_RndSf[i].pTx->GetSurfaceLevel(0, &m_RndSf[i].pSf);
	}

	m_pd3dDevice->GetRenderTarget(0,&m_pCurBck);
	m_pd3dDevice->GetDepthStencilSurface(&m_pCurDpt);

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnLostDevice();


	SAFE_RELEASE(	m_pCurBck	);
	SAFE_RELEASE(	m_pCurDpt	);

	for(int i=0; i<4; ++i)
	{
		m_RndSf[i].Invalidate();
	}

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);
	SAFE_FRMOV(	m_pCamMn	);
	SAFE_FRMOV(	m_pField	);

	RECT rc ={0,0, m_iTxW, 30};
	
	m_pd3dDevice->SetRenderTarget(0,m_RndSf[0].pSf);
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER, 0x00006699, 1.0f, 0L );
	m_pCamMn->m_pCam1->SetTransformViw();
	m_pCamMn->m_pCam1->SetTransformPrj();
	SAFE_RENDER(	m_pField	);
	m_pD3DXFont->DrawText(NULL, "Left Camera", -1, &rc, 0, D3DXCOLOR(1,1,1,1));

	m_pd3dDevice->SetRenderTarget(0,m_RndSf[1].pSf);
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER, 0x00006699, 1.0f, 0L );
	m_pCamMn->m_pCam2->SetTransformViw();
	m_pCamMn->m_pCam2->SetTransformPrj();
	SAFE_RENDER(	m_pField	);
	m_pD3DXFont->DrawText(NULL, "Right Camera", -1, &rc, 0, D3DXCOLOR(1,1,1,1));


	m_pd3dDevice->SetRenderTarget(0,m_RndSf[2].pSf);
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER, 0x00006699, 1.0f, 0L );
	m_pCamMn->m_pCam3->SetTransformViw();
	m_pCamMn->m_pCam3->SetTransformPrj();
	SAFE_RENDER(	m_pField	);
	m_pD3DXFont->DrawText(NULL, "Top Camera", -1, &rc, 0, D3DXCOLOR(1,1,1,1));


	m_pd3dDevice->SetRenderTarget(0,m_RndSf[3].pSf);
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER, 0x00006699, 1.0f, 0L );
	m_pCamMn->m_pCam4->SetTransformViw();
	m_pCamMn->m_pCam4->SetTransformPrj();
	SAFE_RENDER(	m_pField	);
	m_pD3DXFont->DrawText(NULL, "Back Camera", -1, &rc, 0, D3DXCOLOR(1,1,1,1));


	m_pd3dDevice->SetRenderTarget(0,m_pCurBck);		//���� Ÿ���� �������
	m_pd3dDevice->SetDepthStencilSurface(m_pCurDpt);

	return S_OK;
}


HRESULT CMain::Render()
{
	HRESULT hr=0;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L
						);


	m_pCamMn->m_pCam0->SetTransformViw();
	m_pCamMn->m_pCam0->SetTransformPrj();

	//�׸��带 �׸���.
	SAFE_RENDER(	m_pGrid		);

	SAFE_RENDER(	m_pField	);


	RECT		rc = {0,0,m_iTxW, m_iTxW};
	D3DXVECTOR3	vcPos;

	for(int i=0; i<4; ++i)
	{
		vcPos	= D3DXVECTOR3(i,0, 0) * m_iTxW;

		m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND);
		m_pd3dSprite->Draw(m_RndSf[i].pTx, &rc, NULL, &vcPos, D3DXCOLOR(1,1,1,1));
		m_pd3dSprite->End();
	}
	
	
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	

	char	sMsg[256]={0};
	sprintf( sMsg, "%s %s", m_strDeviceStats, m_strFrameStats	);
	SetRect(&rc, 2, 550, m_d3dsdBackBuffer.Width - 20, 580);

	m_pD3DXFont->DrawText(NULL, sMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0));

	m_pd3dDevice->EndScene();
	
	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC m_hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, m_hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}