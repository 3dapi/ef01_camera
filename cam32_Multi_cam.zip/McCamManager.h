// Interface for the CMcCamManager class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McCamManager_H_
#define _McCamManager_H_

class CMcCamManager
{
public:
	CMcCamera*		m_pCam0		;
	CMcCamera*		m_pCam1		;
	CMcCamera*		m_pCam2		;
	CMcCamera*		m_pCam3		;
	CMcCamera*		m_pCam4		;

public:
	CMcCamManager();
	virtual ~CMcCamManager();

	INT		Create(LPDIRECT3DDEVICE9);
	void	Destroy();

	INT		FrameMove();
};

#endif